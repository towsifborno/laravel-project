<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function(){
	
	return redirect()->route('login.index');
});

Route::get('/login', 'LoginController@index')->name('login.index');
Route::post('/login', 'LoginController@verify');
Route::get('/logout', 'LogoutController@index')->name('logout.index');

Route::group(['middleware'=>['admin_type']], function(){

Route::get('/home', 'HomeController@index')->name('home.index');

Route::get('/CarPark', 'ParkController@create')->name('park.create');
Route::post('/CarPark', 'ParkController@store');

Route::get('/ReleaseCar', 'ParkController@release')->name('park.release');
Route::post('/ReleaseCar', 'ParkController@releasePost');

Route::get('/DeleteCar/{id}', 'ParkController@deleteCar')->name('park.deleteCar');

Route::get('/CarList', 'ParkController@CarList')->name('park.CarList');
Route::get('/CarLog', 'ParkController@CarLog')->name('park.CarLog');

});