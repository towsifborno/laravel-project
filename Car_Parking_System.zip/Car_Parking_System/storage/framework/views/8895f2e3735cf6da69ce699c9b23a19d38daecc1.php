<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/bdtourinfo_find_nearest_post_list_v1-1.css">
    <link rel="stylesheet" href="assets/css/bdtourinfo_find_nearest_post_list_v1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Table-with-search-1.css">
    <link rel="stylesheet" href="assets/css/Table-with-search.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
</head>

<body>

    <div style="margin-bottom: 80px;">
        <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean" style="background-color: #37434d;">
            <div class="container"><a class="navbar-brand" href="<?php echo e(route('home.index')); ?>" style="color: #eeeeee;">Car Parking System</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('home.index')); ?>" style="color: #eeeeee;">Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.create')); ?>" style="color: #eeeeee;">Park Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.release')); ?>" style="color: #eeeeee;">Release Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.CarList')); ?>" style="color: #eeeeee;">Car List</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.CarLog')); ?>" style="color: #eeeeee;">Park Log</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('logout.index')); ?>" style="color: #eeeeee;">Logout</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>


  <div class="form-group pull-right">
    <input type="text" class="search form-control" placeholder="What you looking for?">
</div>
<span class="counter pull-right"></span>
<table class="table table-hover table-bordered results">
  <thead>
    <tr>
      <th class="col-xs-2">Car Name</th>
      <th class="col-xs-2">Car Number</th>
      <th class="col-xs-1">Car Type</th>
      <th class="col-xs-2">Owner Name</th>
      <th class="col-xs-2">Phone Number</th>
      <th class="col-xs-1">Cash</th>
      <th class="col-xs-1">In Time</th>
      <th class="col-xs-1">Out Time</th>
    </tr>
    <tr class="warning no-result">
      <td colspan="4"><i class="fa fa-warning"></i> No result</td>
    </tr>
  </thead>
  <tbody>

  <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <td><?php echo e($car->car_name); ?></td>
      <td><?php echo e($car->car_number); ?></td>
      <td><?php echo e($car->car_type); ?></td>
      <td><?php echo e($car->owner_name); ?></td>
      <td><?php echo e($car->phone_number); ?></td>
      <td><?php echo e($car->cash); ?></td>
      <td><?php echo e($car->in_time); ?></td>
      <td><?php echo e($car->out_time); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Table-with-search.js"></script>
</body>

</html><?php /**PATH C:\Users\Tonmoy\Desktop\Project Borno\Car_Parking_System\resources\views/CarLog/index.blade.php ENDPATH**/ ?>