<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Release Car</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
</head>

<body>


        <div style="margin-bottom: 120px;">
        <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean" style="background-color: #37434d;">
            <div class="container"><a class="navbar-brand" href="<?php echo e(route('home.index')); ?>" style="color: #eeeeee;">Car Parking System</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('home.index')); ?>" style="color: #eeeeee;">Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.create')); ?>" style="color: #eeeeee;">Park Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.release')); ?>" style="color: #eeeeee;">Release Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.CarList')); ?>" style="color: #eeeeee;">Car List</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.CarLog')); ?>" style="color: #eeeeee;">Park Log</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('logout.index')); ?>" style="color: #eeeeee;">Logout</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>

        <?php if(session('message') != null): ?>
            <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                     <strong>Warning!</strong> No Car found!!
            </div>
        <?php endif; ?>


    <form method="post" style="margin: 5px;margin-right: 10px;margin-top: 10px;margin-bottom: 10px;margin-left: 40px;">
        <?php echo e(csrf_field()); ?>

        <div class="form-row">
            <div class="col-sm-6" style="max-width: 180px;">
                <div class="form-group"><label>Car Number:&nbsp;</label></div>
            </div>
            <div class="col-sm-6 col-sm-9">
                <div class="form-group"><input class="form-control" type="text" name="carNumber" style="height: 34px;"></div>
            </div>
        </div>
        <div class="form-row">
            <div class="col-sm-6" style="max-width: 180px;">
                <div class="form-group"><label>Owner Number:&nbsp;</label></div>
            </div>
            <div class="col-sm-6 col-sm-9">
                <div class="form-group"><input class="form-control" type="text" name="ownerNumber"  style="height: 34px;"></div>
            </div>
        </div>
        <div class="form-row">
            <div class="col-sm-4 col-md-10 offset-md-5 col-sm-3" style="max-width: 200px;">
                <div class="form-group"><button class="btn btn-primary" style="background-color: rgb(7,55,108);margin: 0px;margin-right: 10px;margin-left: 10px;" type="submit">Submit</button><button class="btn btn-primary" style="background-color: rgb(7,55,108);margin-left: 10px;margin-right: 10px;"
                        type="reset">Reset</button></div>
            </div>
        </div>
    </form>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH C:\Users\Tonmoy\Desktop\Project Borno\Car_Parking_System\resources\views/ReleaseCar/index.blade.php ENDPATH**/ ?>