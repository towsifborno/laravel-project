<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
</head>

<body>

        <div style="margin-bottom: 120px;">
        <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean" style="background-color: #37434d;">
            <div class="container"><a class="navbar-brand" href="<?php echo e(route('home.index')); ?>" style="color: #eeeeee;">Car Parking System</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('home.index')); ?>" style="color: #eeeeee;">Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.create')); ?>" style="color: #eeeeee;">Park Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.release')); ?>" style="color: #eeeeee;">Release Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.CarList')); ?>" style="color: #eeeeee;">Car List</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('park.CarLog')); ?>" style="color: #eeeeee;">Park Log</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(route('logout.index')); ?>" style="color: #eeeeee;">Logout</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>



        <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger alert-dismissible" style="padding: 5px;margin-bottom: 5px;">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" style="padding: 2px;">&times;</a>
                <?php echo e($err); ?> <br>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(session('success') != null): ?>
                 <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                     <strong>Success!</strong> Car details has been recorded successfully 
                 </div>
        <?php endif; ?>


    <form method="post" style="margin: 5px;margin-right: 10px;margin-top: 10px;margin-bottom: 10px;margin-left: 50px;">
        <?php echo e(csrf_field()); ?>

        <div class="form-row">
            <div class="col-sm-6" style="max-width: 180px;">
                <div class="form-group"><label>Car Name:&nbsp;</label></div>
            </div>
            <div class="col-sm-6 col-sm-9">
                <div class="form-group"><input class="form-control" type="text" style="height: 34px;" name="carName" required=""></div>
            </div>
        </div>
        <div class="form-row">
            <div class="col-sm-6" style="max-width: 180px;">
                <div class="form-group"><label>Car Number</label></div>
            </div>
            <div class="col-sm-6 col-sm-9">
                <div class="form-group"><input class="form-control" type="text" style="height: 34px;" required="" name="CarNumber"></div>
            </div>
        </div>
        <div class="form-row">
            <div class="col-sm-4 col-md-5">
                <div class="form-group d-flex"><label style="margin-right: 8px;margin-top: 5px;min-width: 72px;">Car Type:&nbsp;</label><select style="margin-left: 100px;" class="form-control" name="CarType" required=""><option value="Jeep" selected="">Jeep</option><option value="Car">Car</option><option value="Mini Bus">Mini Bus</option><option value="Pick Up">Pick Up</option></select></div>
            </div>
        </div>
        <div class="form-row">
            <div class="col-sm-6" style="max-width: 180px;">
                <div class="form-group"><label>Owner Name:</label></div>
            </div>
            <div class="col-sm-6 col-sm-9">
                <div class="form-group"><input class="form-control" type="text" style="height: 34px;" name="OwnerName" required=""></div>
            </div>
            <div class="col-sm-6" style="max-width: 180px;">
                <div class="form-group"><label>Phone Number:</label></div>
            </div>
            <div class="col-sm-6 col-sm-9">
                <div class="form-group"><input class="form-control" type="text" name="PhoneNumber" required=""></div>
            </div>
        </div>
        <div class="form-row">

            <div class="col-sm-3" style="max-width: 160px;">
                <div class="form-group" ><label>Cash:&nbsp;</label></div>
            </div>
            <div class="col-sm-3">
                <div class="form-group"><input class="form-control" style="margin-left: 20px;" type="number" min="20" max="500" name="Cash" required=""></div>
            </div>
        </div>
        <div class="form-row">
            
            <div class="col text-center"><button class="btn btn-primary" type="submit">Submit</button></div>
        </div>
    </form>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH C:\Users\Tonmoy\Desktop\Project Borno\Car_Parking_System\resources\views/ParkCar/index.blade.php ENDPATH**/ ?>