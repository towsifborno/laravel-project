<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bdtourinfo_login_form_v1-1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bdtourinfo_login_form_v1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">
</head>

<body>
    <div class="register-photo">
        <div class="form-container" style="max-width: 500px;">
            <form method="post">
                <h2 class="text-center"><strong>Login&nbsp;</strong></h2>
                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" required=""></div>
                <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" required="" minlength="4" maxlength="12"></div>
                <div class="form-group"><button class="btn btn-primary btn-block" style="background-color: rgb(7,55,108);" type="submit">Login</button></div>
            </form>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html><?php /**PATH C:\Users\Tonmoy\Desktop\Project Borno\Car_Parking_System\resources\views/login/index.blade.php ENDPATH**/ ?>