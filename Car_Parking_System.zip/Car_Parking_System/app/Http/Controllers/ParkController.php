<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
//use App\User;
use Illuminate\Support\Facades\DB;
use Validator;


class ParkController extends Controller
{
    public function create(Request $request){

    return view('ParkCar.index');
    }

  public function store(Request $request){
      

       $this->validate($request, [
            'carName'=>'bail|Required',
            'CarNumber'=>'bail|Required',
            'CarType'=>'bail|Required',
            'OwnerName'=>'bail|Required',
            'PhoneNumber'=>'bail|Required',
            'Cash'=>'bail|Required'
            

        ]);

       
        $time= date('Y-m-d-h:m:s');



        DB::table('parked_car')->insert(
            ['car_name' => $request->carName, 
             'car_number' => $request->CarNumber,
             'car_type' => $request->CarType,
             'owner_name' => $request->OwnerName,
             'phone_number' => $request->PhoneNumber,
             'cash' => $request->Cash,
             'in_time' => $time ]

        );


       $request->session()->flash('success', 'success');
        return view('ParkCar.index');
      

        
    }

       public function release(Request $request){

            return view('ReleaseCar.index');
    }

        public function releasePost(Request $request){
        
        $carNumber = $request->carNumber;
        $ownerNumber = $request->ownerNumber;
     
        $car = DB::table('parked_car')
                ->where('car_number', $carNumber)
                ->where('phone_number', $ownerNumber)
                ->first();

        if($car != null){

            //$request->session()->put('user', $user->email);
             return view('ReleaseCarReview.index')->with('car', $car);
            
        }else{

            $request->session()->flash('message', 'No Car found');
            return redirect()->route('park.release');
        }
        
    }


    public function deleteCar(Request $request,$id){

            $car = DB::table('parked_car')
                ->where('id', $id)
                ->first();


        $time= date('Y-m-d-h:m:s');


        DB::table('car_log')->insert(
            ['car_name' => $car->car_name, 
             'car_number' => $car->car_number,
             'car_type' => $car->car_type,
             'owner_name' => $car->owner_name,
             'phone_number' => $car->phone_number,
             'cash' => $car->cash,
             'out_time' => $time,
             'in_time' => $car->in_time ]

        );


            DB::table('parked_car')->where('id', $id)->delete();
           return redirect()->route('home.index');
    }


    public function CarList(Request $request){

    $car = DB::table('parked_car')->get();

    return view('CarList.index', ['car' => $car]);

    }

    public function CarLog(Request $request){

    $car = DB::table('car_log')->get();

    return view('CarLog.index', ['car' => $car]);

    }



}
