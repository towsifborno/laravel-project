<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/bdtourinfo_admin_panel_button_v1-1.css">
    <link rel="stylesheet" href="assets/css/bdtourinfo_admin_panel_button_v1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
</head>

<body>

    <div>
        <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean" style="background-color: #37434d;padding-top: 10px;padding-right: 16px;padding-bottom: 10px;">
            <div class="container"><a class="navbar-brand" href="{{route('home.index')}}" style="color: #eeeeee;font-size: 30px;">Car Parking System</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('logout.index')}}" style="color: #eeeeee;">Logout</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>


    <div class="d-flex flex-row justify-content-center" style="margin-top: 200px;margin-bottom: 10px;margin-right: 3px;margin-left: 3px;">
        <div class="row" style="width: 750px;">
            <div class="col-12 col-lg-3 d-flex justify-content-center col-sm-12 col-md-4" style="padding-right: 7px;padding-left: 7px;">
                <div class="d-flex flex-column justify-content-center align-items-center cls_admin_button_div"><a class="btn btn-primary btn-block d-flex flex-column justify-content-center align-items-center icon-button" data-bs-hover-animate="pulse" style="background-color: rgb(52,23,39);margin-top: -4px;color: white;" role="button" href="{{route('park.create')}}"><i class="fa fa-car d-flex" style="font-size: 26px;"></i><span class="d-flex">Park Car</span></a></div>
            </div>
            <div class="col-12 col-lg-3 d-flex justify-content-center col-sm-12 col-md-4" style="padding-right: 7px;padding-left: 7px;">
                <div class="d-flex justify-content-center align-items-center cls_admin_button_div"><a class="btn btn-primary btn-block d-flex flex-column justify-content-center align-items-center icon-button" data-bs-hover-animate="pulse" style="background-color: rgb(52,23,39);margin-top: 0px;color: white;" role="button" href="{{route('park.release')}}"><i class="icon ion-android-menu d-flex" style="font-size: 26px;"></i><span class="d-flex">Release Car</span></a></div>
            </div>
            <div class="col-12 col-lg-3 d-flex justify-content-center col-sm-12 col-md-4" style="padding-right: 7px;padding-left: 7px;">
                <div class="d-flex justify-content-center align-items-center cls_admin_button_div"><a class="btn btn-primary btn-block d-flex flex-column justify-content-center align-items-center icon-button" data-bs-hover-animate="pulse" style="background-color: rgb(52,23,39);margin-top: 0px;color: white;" role="button" href="{{route('park.CarList')}}" ><i class="icon ion-ios-list d-flex" style="font-size: 26px;"></i><span class="d-flex">Car List</span></a></div>
            </div>
            <div class="col-12 col-lg-3 d-flex justify-content-center col-sm-12 col-md-4" style="padding-right: 7px;padding-left: 7px;">
                <div class="d-flex justify-content-center align-items-center cls_admin_button_div"><a class="btn btn-primary btn-block d-flex flex-column justify-content-center align-items-center icon-button" data-bs-hover-animate="pulse" style="background-color: rgb(52,23,39);margin-top: 0px;color: white;" role="button" href="{{route('park.CarLog')}}"><i class="icon ion-android-list d-flex" style="font-size: 26px;"></i><span class="d-flex">Park Log</span></a></div>
            </div>

        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-animation.js"></script>
</body>

</html>