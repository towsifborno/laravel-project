<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
        <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
</head>

<body>

        <div style="margin-bottom: 120px;">
        <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean" style="background-color: #37434d;">
            <div class="container"><a class="navbar-brand" href="{{route('home.index')}}" style="color: #eeeeee;">Car Parking System</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('home.index')}}" style="color: #eeeeee;">Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.create')}}" style="color: #eeeeee;">Park Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.release')}}" style="color: #eeeeee;">Release Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.CarList')}}" style="color: #eeeeee;">Car List</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.CarLog')}}" style="color: #eeeeee;">Park Log</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('logout.index')}}" style="color: #eeeeee;">Logout</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>


    <div id="post_description_page" style="margin-left: 10%;margin-right: 5px;margin-top: 5px;margin-bottom: 5px;">
        <div class="row" id="id_post_description_info_row">
            <div class="col col-md-9" id="id_post_description_info__column">
                <div>
                    <div class="row" style="margin-top: 5px;margin-bottom: 5px;">
                        <div class="col-md-7" id="id_post_description_info_district_column">
                            <div class="d-flex">
                                <h5 style="margin-right: 5px;">Car Number:</h5>
                                <h5 style="margin-left: 5px;">{{$car->car_number}}</h5>
                            </div>
                        </div>
                        <div class="col-md-5" id="id_post_description_info_division_column">
                            <div class="d-flex">
                                <h5 style="margin-right: 5px;">Owner Number:</h5>
                                <h5 style="margin-left: 5px;">{{$car->phone_number}}</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row" id="id_post_description_description_row" style="margin-top: 5px;margin-bottom: 5px;">
            <div class="col col-md-2" id="id_post_description_description_title_column">
                <h5 style="padding-top: 0px;padding-bottom: 0px;margin-top: 5px;margin-bottom: 13px;">Car Name:</h5>
            </div>
            <div class="col col-md-10" id="id_post_description_description_data_column">
                <p style="margin-bottom: 13px;margin-left: 6px;margin-top: 5px;">{{$car->car_name}}<br></p>
            </div>
        </div>
        <div class="row" id="id_post_description_direction_row" style="margin-top: 5px;margin-bottom: 5px;">
            <div class="col col-md-2" id="id_post_description_direction_title_column">
                <h5 style="padding-top: 0px;padding-bottom: 0px;margin-top: 5px;margin-bottom: 13px;">Car Type</h5>
            </div>
            <div class="col col-md-10" id="id_post_description_direction_data_column">
                <p style="margin-bottom: 13px;margin-left: 6px;margin-top: 5px;">{{$car->car_type}}<br></p>
            </div>
        </div>
        <div class="row" id="id_post_description_author_row" style="margin-top: 5px;margin-bottom: 5px;">
            <div class="col col-md-2" id="id_post_description_author_title_column">
                <h5 style="padding-top: 0px;padding-bottom: 0px;margin-top: 5px;margin-bottom: 13px;">Owner Name:</h5>
            </div>
            <div class="col col-md-10" id="id_post_description_author_data_column">
                <p style="margin-bottom: 13px;margin-left: 6px;margin-top: 5px;">{{$car->owner_name}}<br></p>
            </div>
        </div>
        <div class="row" style="margin-top: 5px;margin-bottom: 5px;">
        <div class="col-md-5" id="id_post_description_info_district_column">
            <div class="d-flex" style="margin: 1px;">
                <h5 style="margin-right: 5px;">In Time:</h5>
                <h5 style="margin-left: 5px;font-size: 16px;margin-top: 3px;">{{$car->in_time}}</h5>
            </div>
        </div>
        <div class="col-md-5" id="id_post_description_info_division_column">
            <div class="d-flex">
                <h5 style="margin-right: 5px;">Cash:</h5>
                <h5 style="margin-left: 5px;font-size: 16px;font-weight: 400;margin-top: 3px;">{{$car->cash}}</h5>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;margin-bottom: 5px;">
        <div class="col-md-5 text-center" id="id_post_description_info_district_column"><a class="btn btn-primary" role="button" href="{{route('park.deleteCar',[$car->id])}}">Release</a></div>
        <div class="col-md-5 text-center" id="id_post_description_info_division_column"><a class="btn btn-primary" role="button" href="{{route('park.release')}}">Cancle</a></div>
    </div>
    </div>
    
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>