<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/bdtourinfo_find_nearest_post_list_v1-1.css">
    <link rel="stylesheet" href="assets/css/bdtourinfo_find_nearest_post_list_v1.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Table-with-search-1.css">
    <link rel="stylesheet" href="assets/css/Table-with-search.css">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
</head>

<body>

    <div style="margin-bottom: 80px;">
        <nav class="navbar navbar-light navbar-expand-md fixed-top navigation-clean" style="background-color: #37434d;">
            <div class="container"><a class="navbar-brand" href="{{route('home.index')}}" style="color: #eeeeee;">Car Parking System</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('home.index')}}" style="color: #eeeeee;">Home</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.create')}}" style="color: #eeeeee;">Park Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.release')}}" style="color: #eeeeee;">Release Car</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.CarList')}}" style="color: #eeeeee;">Car List</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('park.CarLog')}}" style="color: #eeeeee;">Park Log</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{route('logout.index')}}" style="color: #eeeeee;">Logout</a></li>
                    </ul>
            </div>
    </div>
    </nav>
    </div>


  <div class="form-group pull-right">
    <input type="text" class="search form-control" placeholder="What you looking for?">
</div>
<span class="counter pull-right"></span>
<table class="table table-hover table-bordered results">
  <thead>
    <tr>
      <th class="col-xs-2">Car Name</th>
      <th class="col-xs-2">Car Number</th>
      <th class="col-xs-1">Car Type</th>
      <th class="col-xs-2">Owner Name</th>
      <th class="col-xs-2">Phone Number</th>
      <th class="col-xs-1">Cash</th>
      <th class="col-xs-1">In Time</th>
      <th class="col-xs-1">Out Time</th>
    </tr>
    <tr class="warning no-result">
      <td colspan="4"><i class="fa fa-warning"></i> No result</td>
    </tr>
  </thead>
  <tbody>

  @foreach($car as $car)

    <tr>
      <td>{{$car->car_name}}</td>
      <td>{{$car->car_number}}</td>
      <td>{{$car->car_type}}</td>
      <td>{{$car->owner_name}}</td>
      <td>{{$car->phone_number}}</td>
      <td>{{$car->cash}}</td>
      <td>{{$car->in_time}}</td>
      <td>{{$car->out_time}}</td>
    </tr>

    @endforeach
    
  </tbody>
</table>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/Table-with-search.js"></script>
</body>

</html>