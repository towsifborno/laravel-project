<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Login</title>
    <link rel="stylesheet" href="{{asset('assets/bootstrap/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/bdtourinfo_login_form_v1-1.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/bdtourinfo_login_form_v1.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/styles.css')}}">
    <link rel="stylesheet" href="assets/css/Navigation-Clean.css">
</head>

<body>


    <div>
        <nav class="navbar navbar-light navbar-expand-md fixed-top text-left navigation-clean" style="background-color: #37434d;padding-top: 10px;padding-right: 16px;padding-bottom: 10px;">
            <div class="container"><a class="navbar-brand d-md-flex justify-content-md-center" href="#" style="color: #eeeeee;font-size: 30px;width: 100vw;">Car Parking System</a></div>
        </nav>
    </div>



        @if(session('message') != null)
            <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                     <strong>Warning!</strong> Invalid Username or Password!!
            </div>
        @endif

        @if($errors->any())
                @foreach($errors->all() as $err)
                <div class="alert alert-danger alert-dismissible" style="padding: 5px;margin-bottom: 5px;">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" style="padding: 2px;">&times;</a>
                {{$err}} <br>
                </div>
                @endforeach
        @endif


    <div class="register-photo" style="margin-top: 50px;">
        <div class="form-container" style="max-width: 500px;">
            <form method="post">
                 {{ csrf_field() }}
                <h2 class="text-center"><strong>Login&nbsp;</strong></h2>
                <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email" required="" value="{{old('email')}}"></div>
                <div class="form-group"><input class="form-control" type="password" name="password" placeholder="Password" required="" minlength="4" maxlength="12"></div>
                <div class="form-group"><button class="btn btn-primary btn-block" style="background-color: rgb(7,55,108);" type="submit">Login</button></div>
            </form>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>